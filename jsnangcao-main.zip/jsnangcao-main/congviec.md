### Khoa học Udemy
- 09 lab: download
- 120 video: xem, tua, tích pass
- Hoan 100% khoa học online

### Git:
- Tao nick GitHub
- Tao Repo JS Nang cao
    - Udemy: 9 lab (+ diem)
    - JS nang cao: https://github.com/bradtraversy/javascript-sandbox
        - 01 - 10: bai thuc hanh
- Project hoan thiên: Xay dung web danh sách sp, CRUD (them, sua, xoa)
